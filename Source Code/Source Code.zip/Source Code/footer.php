<div class="clr"></div>
<div class="footer">
  <div class="footer_resize"><a href="#"><img src="images/onlineexaminationlogo.gif" alt="picture" width="223" height="64" border="0" /></a>
    <p class="leftt">© Copyright <?php echo date("Y"); ?> Online Examination System<br />
      Designed by <a href="https://www.studentprojectguide.com" target="_blank">StudentProjectGuide</a></p>
    <div class="clr"></div>
  </div>
  <div class="clr"></div>
</div>
  </div>
  
</div>

</body>
</html>