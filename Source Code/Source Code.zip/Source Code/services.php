<?php
session_start();
include("header.php");
?>
    <div class="slider_top2">
<h2>Services</h2>
<p>“It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.Content here, content here', making it look like readable English.”<br />
  <a href="#">by: John S., businessman</a></p>
    </div>
    <div class="clr"></div>
    <div class="body_resize">
              <div class="body">
              <div class="left">
              <h2 class="serv"> Services Company</h2>
               <h3>Featured Services #1</h3>
        <img src="images/sevr_1.jpg" alt="picture" width="172" height="147" />
        <p>Vestibulum sit amet neque eu neque suscipit consequat quis vel risus. Vestibulum vehicula purus nec dui accumsan fermentum. Suspendisse potenti. Ut dapibus est id odio pretium blandit in eget leo. </p>
        <ul>
          <li>Lorem Ipsum is simply dummy text </li>
          <li>Lorem Ipsum has been the industry's standard </li>
          <li>It has survived not only five centuriest </li>
          <li>Lorem Ipsum passages<br />
          </li>
        </ul>
<p><a href="#" style="color:#b73214;"><strong>Order Now </strong></a></p>
<p>&nbsp;</p>
 <h3>Featured Services #2</h3>
        <img src="images/sevr_2.jpg" alt="picture" width="172" height="147" />
        <p>Vestibulum sit amet neque eu neque suscipit consequat quis vel risus. Vestibulum vehicula purus nec dui accumsan fermentum. Suspendisse potenti. Ut dapibus est id odio pretium blandit in eget leo. </p>
        <ul>
          <li>Lorem Ipsum is simply dummy text </li>
          <li>Lorem Ipsum has been the industry's standard </li>
          <li>It has survived not only five centuriest </li>
          <li>Lorem Ipsum passages<br />
          </li>
        </ul>
<p><a href="#" style="color:#b73214;"><strong>Order Now </strong></a></p>
<p>&nbsp;</p>
 <h3>Featured Services #3</h3>
        <img src="images/sevr_3.jpg" alt="picture" width="172" height="147" />
        <p>Vestibulum sit amet neque eu neque suscipit consequat quis vel risus. Vestibulum vehicula purus nec dui accumsan fermentum. Suspendisse potenti. Ut dapibus est id odio pretium blandit in eget leo. </p>
        <ul>
          <li>Lorem Ipsum is simply dummy text </li>
          <li>Lorem Ipsum has been the industry's standard </li>
          <li>It has survived not only five centuriest </li>
          <li>Lorem Ipsum passages<br />
          </li>
        </ul>
<p><a href="#" style="color:#b73214;"><strong>Order Now </strong></a></p>
<p>&nbsp;</p>
              </div>
        
         <div class="right">
          <?php
		  include("usersidebar.php");
		  ?>
         </div>
         
        <div class="clr"></div>
      </div>
    </div>
<?php
include("footer.php");
?>