<?php
session_start();
?>
<!--
     <h2 class="Welco"><a href="myaccount.php">Home</a></h2>
		  <h2 class="Welco"><a href="examtimetable.php">Exam Time Table</a></h2>
		  <h2 class="Welco"><a href="hallticket.php">Hall ticket</a></h2>
		  <h2 class="Welco"><a href="attendexam.php">Attend Exam</a></h2> 
		  <h2 class="Welco">Results</h2>  
          <h2 class="Welco">Certificate</h2> 
          <h2 class="Welco"><a href='logout.php'>Logout</a></h2>
-->          