<?php
session_start();
include("header.php");
?>
     <div class="slider_top2">
<h2>About Us</h2>
<p>“It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.Content here, content here', making it look like readable English.”<br />
  <a href="#">by: John S., businessman</a></p>
    </div>
    <div class="clr"></div>
    <div class="body_resize">
              <div class="body">
              <div class="left">
              <h2 class="about"> About Us</h2>
              <p>Epsum factorial non deposit quid pro quo hic escorol. Olypian quarrels et gorilla congolium sic ad nauseum. Souvlaki ignitus carborundum pluribus unum. Defacto lingo est igpay atinlay. Marquee selectus non provisio incongruous feline nolo contendre.Epsum factorial non deposit quid pro quo hic escorol.</p>
              <p>Olypian quarrels et gorilla congolium sic ad nauseum. Souvlaki ignitus carborundum pluribus unum. Defacto lingo est igpay atinlay. Marquee selectus non provisio incongruous feline nolo contendre. Epsum factorial non deposit quid pro quo hic escorol. Olypian quarrels et gorilla congolium sic ad nauseum. Souvlaki ignitus carborundum pluribus unum. Defacto lingo est igpay atinlay. Marquee selectus non provisio incongruous feline nolo contendre.</p>
              <p>&nbsp;</p>
              <h2 class="team"> Our Team</h2>
              <p>Epsum factorial non deposit quid pro quo hic escorol. Olypian quarrels et gorilla congolium sic ad nauseum. Souvlaki ignitus carborundum pluribus unum. Defacto lingo est igpay atinlay. </p>
              <img src="images/about_img.gif" alt="picture" width="103" height="109" />
              <p><strong>Director</strong></p>
              <p>Epsum factorial non deposit quid pro quo hic escorol. Olypian quarrels et gorillasic ad nauseum. Souvlaki ignitus carborundum pluribus unum. Defacto lingo est igpay.</p>
              <p><a href="#"><img src="images/img_img1.gif" alt="0" width="25" height="25" border="0" /></a><a href="#"><img src="images/img_img.gif" alt="picture" width="25" height="25" border="0" /></a><a href="#"><img src="images/img_img2.gif" alt="picture" width="25" height="25" border="0" /></a><a href="#"><img src="images/img_img3.gif" alt="picture" width="25" height="25" border="0" /></a></p>
              <div class="bg"></div>
              <img src="images/about_img.gif" alt="picture" width="103" height="109" />
              <p><strong>Manager</strong></p>
              <p>Epsum factorial non deposit quid pro quo hic escorol. Olypian quarrels et gorillasic ad nauseum. Souvlaki ignitus carborundum pluribus unum. Defacto lingo est igpay.</p>
              <p><a href="#"><img src="images/img_img1.gif" alt="0" width="25" height="25" border="0" /></a><a href="#"><img src="images/img_img.gif" alt="picture" width="25" height="25" border="0" /></a><a href="#"><img src="images/img_img2.gif" alt="picture" width="25" height="25" border="0" /></a><a href="#"><img src="images/img_img3.gif" alt="picture" width="25" height="25" border="0" /></a></p>
              <div class="bg"></div>
              <img src="images/about_img.gif" alt="picture" width="103" height="109" />
              <p><strong>Designer</strong></p>
              <p>Epsum factorial non deposit quid pro quo hic escorol. Olypian quarrels et gorillasic ad nauseum. Souvlaki ignitus carborundum pluribus unum. Defacto lingo est igpay.</p>
              <p><a href="#"><img src="images/img_img1.gif" alt="0" width="25" height="25" border="0" /></a><a href="#"><img src="images/img_img.gif" alt="picture" width="25" height="25" border="0" /></a><a href="#"><img src="images/img_img2.gif" alt="picture" width="25" height="25" border="0" /></a><a href="#"><img src="images/img_img3.gif" alt="picture" width="25" height="25" border="0" /></a></p>
              <div class="bg"></div>
              </div>
        
         <div class="right">
          <?php
		  include("usersidebar.php");
		  ?>
         </div>
         
        <div class="clr"></div>
      </div>
    </div>
<?php
include("footer.php");
?>